import tkinter as tk


root = tk.Tk()


root.title("froogle boopen boppen") 
root.geometry("1920x1080")            

img = tk.PhotoImage(file="froog.png")
label = tk.Label(root, image=img)
label.pack()

input("Press Enter to exit...")

root.mainloop()
